# -*- coding: UTF-8 -*-

# 2022-01-07

import re
try:
    import resolveurl as resolver
except:
    import urlresolver as resolver

from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils
from scrapers.modules.tools import cParser
from resources.lib.control import urlparse, urljoin, getSetting, quote_plus

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['hdfilme.top']
        self.base_link = 'https://hdfilme.top'
        self.search_link = self.base_link + '/index.php?do=search'
        self.search_api = self.base_link + '/search'
        self.get_link = 'movie/load-stream/%s/%s?'
        self.sources = []
        self.checkHoster = True
        self.quality = 'HD'



    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        url = ''
        t = [cleantitle.get(i) for i in set(titles) if i]
        links = []
        for sSearchText in titles:
            try:
                oRequest = cRequestHandler(self.search_link)
                oRequest.addParameters('do', 'search')
                oRequest.addParameters('subaction', 'search')
                oRequest.addParameters('search_start', '0')
                oRequest.addParameters('full_search', '1')
                oRequest.addParameters('result_from', '1')
                oRequest.addParameters('story', sSearchText)
                oRequest.addParameters('titleonly', '3')
                sHtmlContent = oRequest.request()
                r = dom_parser.parse_dom(sHtmlContent, 'div', attrs={'id': 'dle-content'})[0].content
                pattern = 'href="([^"]+)">\t{3}<span class="film-item-title">([^<]+)'
                isMatch, aResult = cParser.parse(r, pattern)
                if not isMatch: continue
                quality = dom_parser.parse_dom(sHtmlContent, 'span', attrs={'class': 'film-item-quality'})
                if season == 0: #movie
                    for x in range(0, len(aResult)):
                        sUrl = aResult[x][0]
                        sName = aResult[x][1]
                        sQuality = quality[x][1]
                        if cleantitle.get(sName) in t and 'kostenlos' in sUrl:
                            url = sUrl.replace('.html', '/watching.html')
                            break
                    if url: break

                else: #tvshow
                    return

            except:
                 pass

        # print (url +'\n') # test only

        try:
            if not url: return sources
            #'https://hdfilme.top/127-aquaman-kostenlos-auf-deutsch/watching.html'
            query = urljoin(self.base_link, url)
            oRequest = cRequestHandler(query)
            oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
            sHtmlContent = oRequest.request()
            pattern = 'data-link="([^"]+).*?alt="([^"]+)'
            isMatch, aResult = cParser().parse(sHtmlContent, pattern)
            if not isMatch: return sources
            if self.checkHoster:
                from resources.lib import workers
                threads = []
                for sUrl, sName in aResult:
                    # print(sUrl)
                    threads.append(workers.Thread(self.chk_link, sUrl, hostDict, season, episode))
                [i.start() for i in threads]
                [i.join() for i in threads]
            else:
                for sUrl, sName in aResult:
                    if '/index' in sUrl: continue
                    if sUrl.startswith('/'): sUrl = 'https:' + sUrl
                    valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                    if not valid or 'youtube' in hoster: continue
                    self.sources.append({'source': hoster, 'quality': self.quality, 'language': 'de', 'url': sUrl, 'direct': False})

            return self.sources
        except:
            return self.sources

    def chk_link(self, sUrl, hostDict, season, episode):
        try:
            if sUrl.startswith('/'): sUrl = 'https:' + sUrl
            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
            if not valid or 'youtube' in hoster: return
            hmf = resolver.HostedMediaFile(url=sUrl, include_disabled=True, include_universal=False)
            if hmf.valid_url():
                url = hmf.resolve()
                if url: self.sources.append({'source': hoster, 'quality': self.quality, 'language': 'de', 'url': url, 'direct': True})
        except:
            return

    def resolve(self, url):
        try:
            return url
        except:
            return


